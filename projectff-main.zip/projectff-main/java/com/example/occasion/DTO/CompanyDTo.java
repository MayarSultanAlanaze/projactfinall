package com.example.occasion.DTO;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CompanyDTo {
    //private Integer myUser_id;
    private String username;
    private String password;
    private String city;
    private String timecatgory;
//    private String rating;
    private String licensenumber;


}
